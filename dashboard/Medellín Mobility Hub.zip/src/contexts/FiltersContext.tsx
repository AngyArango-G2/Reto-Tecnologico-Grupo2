import { createContext, useContext, useState, ReactNode } from "react";

export interface DashboardFilters {
  comuna: string;
  year: string;
  mode: string;
  corredor: string;
}

interface FiltersContextValue {
  filters: DashboardFilters;
  setComuna: (v: string) => void;
  setYear: (v: string) => void;
  setMode: (v: string) => void;
  setCorredor: (v: string) => void;
  reset: () => void;
}

const defaultFilters: DashboardFilters = { comuna: "all", year: "2023", mode: "all", corredor: "all" };

const FiltersContext = createContext<FiltersContextValue | null>(null);

export const FiltersProvider = ({ children }: { children: ReactNode }) => {
  const [filters, setFilters] = useState<DashboardFilters>(defaultFilters);
  return (
    <FiltersContext.Provider
      value={{
        filters,
        setComuna: (comuna) => setFilters((f) => ({ ...f, comuna })),
        setYear: (year) => setFilters((f) => ({ ...f, year })),
        setMode: (mode) => setFilters((f) => ({ ...f, mode })),
        setCorredor: (corredor) => setFilters((f) => ({ ...f, corredor })),
        reset: () => setFilters(defaultFilters),
      }}
    >
      {children}
    </FiltersContext.Provider>
  );
};

export const useFilters = () => {
  const ctx = useContext(FiltersContext);
  if (!ctx) throw new Error("useFilters must be used within FiltersProvider");
  return ctx;
};
